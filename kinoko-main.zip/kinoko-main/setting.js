/*
 * Creator: Zaenishi
 * WhatsApp: +62 831-8822-9366
 * Instagram: @zaenishi
 * Twitter: @zaenishi
 * GitHub: zaenishi
 *
 * Jangan sungkan untuk menghubungi saya jika ada masalah pada script ini!
*/

export default {
    owner: ["6283188229366"],
    typedb: "json", // use json / mongo

    /* database setting */
    db: {
        local: ".db.json",
        mongo: "url"
    }
}